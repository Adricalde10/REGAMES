<script>
</script>
<template>
    <h1>Peppa la cerda</h1>
    <img src="https://i.pinimg.com/474x/2a/3e/bf/2a3ebf7b38d12b02e1b02a9e24559551.jpg" width="100%"></img>
</template>
<style>
h1{
    text-align: center;
}
</style>